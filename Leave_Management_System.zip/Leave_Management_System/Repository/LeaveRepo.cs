﻿using Leave_Management_System.DataBase;
using Leave_Management_System.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Repository
{
    public class LeaveRepo : ILeaveRepo
    {
        private readonly LMSConnect lMSConnect;

        public LeaveRepo(LMSConnect lMSConnect)
        {
            this.lMSConnect = lMSConnect;
        }

        public async Task<List<EmployeeLeave>> GetAllLeave()
        {
            var ar = await lMSConnect.EmployeeLeaves.ToListAsync();
            return ar;
        }
        public async Task<int> ApplyLeave(EmployeeLeave employeeLeave)
        {
            lMSConnect.EmployeeLeaves.Add(new EmployeeLeave { LeaveId=employeeLeave.LeaveId,EmployeeId=employeeLeave.EmployeeId,ManagerId=employeeLeave.ManagerId,StartDate=employeeLeave.StartDate,EndDate=employeeLeave.EndDate,NoOfDays=employeeLeave.NoOfDays,LeaveType=employeeLeave.LeaveType,LeaveReason=employeeLeave.LeaveReason, Status = employeeLeave.Status, ManagerComment = employeeLeave.ManagerComment });
            await lMSConnect.SaveChangesAsync();
            return employeeLeave.LeaveId;
        }
        public async Task<EmployeeLeave> GetLeaveById(int id)
        {
            var ar = await lMSConnect.EmployeeLeaves.Where(x => x.EmployeeId == id).FirstOrDefaultAsync();
            return ar;
        }

        

        public async Task<int> DeleteLeave(int id)
        {
            var ar = await lMSConnect.EmployeeLeaves.Where(x => x.EmployeeId == id).FirstOrDefaultAsync();
            if (ar != null)
            {
                lMSConnect.EmployeeLeaves.Remove(ar);
                await lMSConnect.SaveChangesAsync();
            }
            return id;
        }

        public async Task<int> ApproveDeny(int levid, EmployeeLeave employeeLeave)
        {
            var ar = await lMSConnect.EmployeeLeaves.Where(x => x.LeaveId == levid).FirstOrDefaultAsync();
            if(ar!=null)
            {
                ar.Status = employeeLeave.Status;
                ar.ManagerComment = employeeLeave.ManagerComment;
                await lMSConnect.SaveChangesAsync();
            }
            return levid;
        }
    }
}
